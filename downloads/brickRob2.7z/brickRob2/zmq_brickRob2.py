# pip install pyzmq cbor keyboard
from zmqRemoteApi import RemoteAPIClient
import keyboard
import random
import math

client = RemoteAPIClient('localhost', 23000)

print('Program started')
sim = client.getObject('sim')
#sim.startSimulation()
print('Simulation started')
Floor= sim.getObject('/Floor')
brickRob= sim.getObject('/brickRob')
s1=sim.getObjectOrientation(brickRob, Floor)
print(s1)
s=(s1[2]*180)/math.pi
def setBubbleRobVelocity(leftWheelVelocity1, rightWheelVelocity1,leftWheelVelocity2, rightWheelVelocity2):
    leftMotor1 = sim.getObject('/joint_lf')
    rightMotor1 = sim.getObject('/joint_rf')
    leftMotor2 = sim.getObject('/joint_lb')
    rightMotor2 = sim.getObject('/joint_rb')
    sim.setJointTargetVelocity(leftMotor1, leftWheelVelocity1)
    sim.setJointTargetVelocity(rightMotor1, rightWheelVelocity1)
    sim.setJointTargetVelocity(leftMotor2, leftWheelVelocity2)
    sim.setJointTargetVelocity(rightMotor2, rightWheelVelocity2)
    #輸入四個變數分別給四個軸速度
    
def setBubbleRobangel(a):
	Floor= sim.getObject('/Floor')
	brickRob= sim.getObject('/brickRob')
	angel = [0*math.pi/180, 0*math.pi/180, a*math.pi/180]
	#leftMotor = sim.getObject('/joint_lf')
	#rightMotor = sim.getObject('/joint_rf')
	sim.setObjectOrientation(brickRob, Floor, angel)
	#sim.setObjectOrientation(rightMotor, brickRob, angel)
	#輸入一個變數改變前輪方向

while True:
    if keyboard.is_pressed('w'):
        setBubbleRobVelocity(4, 4, 4, 4)
        if keyboard.is_pressed('a'):
            s=s+4
            setBubbleRobangel(s)
        elif keyboard.is_pressed('d'):
            s=s-4
            setBubbleRobangel(s)
    elif keyboard.is_pressed('s'):
        setBubbleRobVelocity(-4, -4, -4, -4)
        if keyboard.is_pressed('a'):
            s=s-4
            setBubbleRobangel(s)
        elif keyboard.is_pressed('d'):
            s=s+4
            setBubbleRobangel(s)
    elif keyboard.is_pressed('a'):
        s=s+4
        setBubbleRobangel(s)
    elif keyboard.is_pressed('d'):
        s=s-4
        setBubbleRobangel(s)
    elif keyboard.is_pressed('q'):
        # stop simulation
        sim.stopSimulation()
    else:
        setBubbleRobVelocity(0, 0, 0, 0)





